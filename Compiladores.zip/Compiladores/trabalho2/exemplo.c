int z = 10;

if(z > 20)
    return z;