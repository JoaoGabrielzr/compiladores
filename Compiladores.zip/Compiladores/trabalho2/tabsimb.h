#include<string.h>

#define MAX 1000

struct symbol{
    char lexema[50];
    int tam;
    int tipo;
};

int tam_tab = 0;
struct symbol tabela[MAX];

    int procura(char *lexema){
        int i;
        for(i=0; i <tam_tab; i++)
        if(strcmp(tabela[i].lexema, lexema)==0)
        return i;
        return -1;
    }

int insere(char * lexema){
    int onde_existe;
    struct symbol aux;
    int existe_na_tabela = 1;
    onde_existe = procura(lexema);
    if(onde_existe == -1){
        existe_na_tabela = 0;}
    if(existe_na_tabela){
    
    strcpy(aux.lexema, lexema);

    tabela[tam_tab] = aux;
    return tam_tab++;
    }else 
        return onde_existe;
}
char lexema[50];
char *get_lexema(int pos){
    strcpy(lexema, tabela [pos].lexema);
    return lexema;
}